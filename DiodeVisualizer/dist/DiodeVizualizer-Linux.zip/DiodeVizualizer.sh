#!/bin/sh
java  -jar DiodeVizualizer.jar
        